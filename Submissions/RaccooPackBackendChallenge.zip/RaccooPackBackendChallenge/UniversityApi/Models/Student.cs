﻿namespace UniversityApi.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        public DateOnly DateOfBirth { get; set;}

        public string Gender { get; set; }

        public string Address { get; set; }

        public string City { get; set; }

        public List<Course> Courses { get; set; }
    }
}
