﻿namespace UniversityApi.Models
{
    public class Course
    {
        public string CourseId { get; set; }

        public string CourseName { get; set; }

        public string CourseMaterial { get; set; }

        public decimal CourseFee { get; set; }

        public decimal Credits { get; set; }

        public string LearningObjective { get; set; }

        public int CourseCapacity { get; set; }

        //Insert Faculty Object here
    }
}
