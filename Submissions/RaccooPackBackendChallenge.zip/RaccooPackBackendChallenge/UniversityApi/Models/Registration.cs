﻿namespace UniversityApi.Models
{
    public class Registration
    {
        public int RegistrationId { get; set; }

        public string CourseId { get; set; }

        public int StudentId { get; set; }
    }
}
