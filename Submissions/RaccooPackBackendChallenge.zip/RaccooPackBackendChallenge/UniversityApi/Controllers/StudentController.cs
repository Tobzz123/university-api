﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniversityApi.Models;

namespace UniversityApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        //Let's assume that we have a UniversityContext that can access all DB Tables using DBSet objects of each table =>
        
        //private readonly UniversityContext _context;


        [HttpPut]
        public async Task<ActionResult<Course?>> EnrollInCourse(Student student, Course course)
        {
            if (ReferenceEquals(student, null))
            {
                return BadRequest();
            }

            //Mimics insertion into Registrations Table  => _context.Registrations.AddAsync( new Registration {CourseId = course.CourseId, StudentId = student.StudentId};

            //Save the Changes of the context
            // _context.SaveChanges();

            return Ok($"Enrolled {student} into course: {course.CourseName}");
        }

        [HttpGet]
        public IActionResult GetCourses(string sortOrder, string searchString) {


            IQueryable<Course> courses = null;// = _context.Courses;

            //Apply sorting
            switch (sortOrder)
            {
                case "title_desc":
                    courses = courses.OrderByDescending(c => c.CourseName);
                    break;
                case "credits":
                    courses = courses.OrderBy(c => c.Credits);
                    break;
                case "credits_desc":
                    courses = courses.OrderByDescending(c => c.Credits);
                    break;
                case "fees":
                    courses = courses.OrderBy(c => c.CourseFee);
                    break;
                case "fees_desc":
                    courses = courses.OrderByDescending(c => c.CourseFee);
                    break;
                case "capacity":
                    courses = courses.OrderBy(c => c.CourseCapacity);
                    break;
                case "capacity_desc":
                    courses = courses.OrderByDescending(c => c.CourseCapacity);
                    break;
                default:
                    courses = courses.OrderBy(c => c.CourseName);
                    break;              
            }


            // Apply filtering
            if (!string.IsNullOrEmpty(searchString))
            {
                courses = courses.Where(c => c.CourseName.Contains(searchString));
            }

            var courseList = courses.ToList();
            return Ok(courseList);
        }
    }
}
