﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UniversityApi.Models;

namespace UniversityApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        //Let's assume that we have a UniversityContext that can access all DB Tables using DBSet objects of each table

        private static readonly string[] Courses = new[]
        {
        "COMP 1001", "BUSN 10205", "ACCT 1004", "ENG 1250", "COMP 20305", "CHEM 1308", "COMP 1035", "BIO 3043"
        };


        [HttpPut]
        public ActionResult<Course> EnrollInCourse(Student student, Course course)
        {
            if (object.ReferenceEquals(student, null))
            {
                return BadRequest();
            }

            //Mimics insertion into Registrations Table
            student.Courses.Add(course);
            //Save the Changes of the context
            // _context.SaveChanges();

            return Ok($"Enrolled {student} into course: {course.CourseName}");
        }
    }
}
